//
//  BackendProccess.swift
//  Halcyon
//
//  Created by Bishneet Singh on 2021-01-16.
//

import Foundation
import UIKit
import SwiftUI
import Firebase
import HealthKit

let healthKitStore : HKHealthStore = HKHealthStore()

//<--------------------------Global Variables-------------------------->//
struct globalVars
{
    //These 4 variables need to be assigned with the buttons. Once Assigned run the MainPosting func
    static var happiness : Int!
    static var motivation : Int!
    static var energy : Int!
    static var creativity : Int!
    
    static var Htempvar1 : String = "";
    static var Htempvar2 : String = "";
    static var Htempvar3 : String = "";
    static var Htempvar4 : String = "";
    
    static var Htte1 : String = "";
    static var Htte2 : String = "";
    static var Htte3 : String = "";
    static var Htte4 : String = "";
    
    static var Etempvar1 : String = "";
    static var Etempvar2 : String = "";
    static var Etempvar3 : String = "";
    static var Etempvar4 : String = "";
    
    static var Ette1 : String = "";
    static var Ette2 : String = "";
    static var Ette3 : String = "";
    static var Ette4 : String = "";
    
    static var Mtempvar1 : String = "";
    static var Mtempvar2 : String = "";
    static var Mtempvar3 : String = "";
    static var Mtempvar4 : String = "";
    
    static var Mtte1 : String = "";
    static var Mtte2 : String = "";
    static var Mtte3 : String = "";
    static var Mtte4 : String = "";
    
    static var Ctempvar1 : String = "";
    static var Ctempvar2 : String = "";
    static var Ctempvar3 : String = "";
    static var Ctempvar4 : String = "";
    
    static var Ctte1 : String = "";
    static var Ctte2 : String = "";
    static var Ctte3 : String = "";
    static var Ctte4 : String = "";
    
    
    static var positionRecieve1 : String!
    static var positionRecieve2 : String!
    static var positionRecieve3 : String!
    static var positionRecieve4 : String!
    static var positionRecieve5 : String!
    
    //This is the Max amount of data we want from the health app in each category
    static var queryLimit = 500;
}

class BackendProcesses
{
    
    let healthStore = HKHealthStore()
    

    //<--------------------------App Initalization-------------------------->//
    func onStartup()
    {
        requestAuthorization()
        
        let databaseRef = Database.database().reference()

        databaseRef.child("Client_Data").child("Active_Calories (Cal)").removeValue()
        databaseRef.child("Client_Data").child("Heart_Rate_(bpm)").removeValue()
        databaseRef.child("Client_Data").child("Sleep (seconds)").removeValue()
        databaseRef.child("Client_Data").child("Steps").removeValue()

        readHealthData()
    }

//<--------------------------Manual Input Database Upload-------------------------->//
    func mainPosting()
    {
        let timeStamp = getTimeStamp()
        
        let happinessInput = globalVars.happiness
        let motivationInput = globalVars.motivation
        let energyInput = globalVars.energy
        let creativityInput = globalVars.creativity
    
        let post : [String : Any] = ["TimeStamp" : timeStamp,
                                     "Motivation" : motivationInput ?? -1,
                                     "Energy" : energyInput ?? -1,
                                     "Creativity" : creativityInput ?? -1,
                                     "Happiness" : happinessInput ?? -1]
        
        let databaseRef = Database.database().reference()
        //
        databaseRef.child("Client_Data").child("Manual_Input").childByAutoId().setValue(post)
    }
    
    func getTimeStamp() -> String
    {
        let currentDate = Date()
        let dateFormat = DateFormatter()
        
        dateFormat.timeStyle = .medium
        dateFormat.dateStyle = .medium
        dateFormat.locale = Locale(identifier: "ja_JP")
        
        let stringDate = dateFormat.string(from: currentDate)
        
        return stringDate
    }

    
    //<--------------------------Recieving Machine Learning Results-------------------------->//
    func getPositions()
    {
        let databaseRef = Database.database().reference()
        
        //Happiness
        databaseRef.child("Analized_Data").child("Happy").queryOrderedByKey().observeSingleEvent(of: .value, with: {DataSnapshot in
            
            guard let dict = DataSnapshot.value as? [String : Any] else {print("Error"); return}
            
            globalVars.Htte1 = dict["position1"] as! String
            globalVars.Htte2 = dict["position2"] as! String
            globalVars.Htte3 = dict["position3"] as! String
            globalVars.Htte4 = dict["position4"] as! String
            
            let value1 = dict["pos1Ammount"] as! Double
            let value2 = dict["pos2Ammount"] as! Double
            let value3 = dict["pos3Ammount"] as! Double
            let value4 = dict["pos4Ammount"] as! Double
            
            globalVars.Htempvar1 = "\(value1)"
            globalVars.Htempvar2 = "\(value2)"
            globalVars.Htempvar3 = "\(value3)"
            globalVars.Htempvar4 = "\(value4)"
        })
        
        
        //Energy
        databaseRef.child("Analized_Data").child("Energy").queryOrderedByKey().observeSingleEvent(of: .value, with: {DataSnapshot in
            
            guard let dict = DataSnapshot.value as? [String : Any] else {print("Error"); return}
            
            globalVars.Ette1 = dict["position1"] as! String
            globalVars.Ette2 = dict["position2"] as! String
            globalVars.Ette3 = dict["position3"] as! String
            globalVars.Ette4 = dict["position4"] as! String
            
            let value1 = dict["pos1Ammount"] as! Double
            let value2 = dict["pos2Ammount"] as! Double
            let value3 = dict["pos3Ammount"] as! Double
            let value4 = dict["pos4Ammount"] as! Double
            
            globalVars.Etempvar1 = "\(value1)"
            globalVars.Etempvar2 = "\(value2)"
            globalVars.Etempvar3 = "\(value3)"
            globalVars.Etempvar4 = "\(value4)"
        })
        
        
        //Creativity
        databaseRef.child("Analized_Data").child("Creative").queryOrderedByKey().observeSingleEvent(of: .value, with: {DataSnapshot in
            
            guard let dict = DataSnapshot.value as? [String : Any] else {print("Error"); return}
            
            globalVars.Ctte1 = dict["position1"] as! String
            globalVars.Ctte2 = dict["position2"] as! String
            globalVars.Ctte3 = dict["position3"] as! String
            globalVars.Ctte4 = dict["position4"] as! String
            
            let value1 = dict["pos1Ammount"] as! Double
            let value2 = dict["pos2Ammount"] as! Double
            let value3 = dict["pos3Ammount"] as! Double
            let value4 = dict["pos4Ammount"] as! Double
            
            globalVars.Ctempvar1 = "\(value1)"
            globalVars.Ctempvar2 = "\(value2)"
            globalVars.Ctempvar3 = "\(value3)"
            globalVars.Ctempvar4 = "\(value4)"
        })
        
        
        //Motivation
        databaseRef.child("Analized_Data").child("Motivation").queryOrderedByKey().observeSingleEvent(of: .value, with: {DataSnapshot in
            
            guard let dict = DataSnapshot.value as? [String : Any] else {print("Error"); return}
            
            globalVars.Mtte1 = dict["position1"] as! String
            globalVars.Mtte2 = dict["position2"] as! String
            globalVars.Mtte3 = dict["position3"] as! String
            globalVars.Mtte4 = dict["position4"] as! String
            
            let value1 = dict["pos1Ammount"] as! Double
            let value2 = dict["pos2Ammount"] as! Double
            let value3 = dict["pos3Ammount"] as! Double
            let value4 = dict["pos4Ammount"] as! Double
            
            globalVars.Mtempvar1 = "\(value1)"
            globalVars.Mtempvar2 = "\(value2)"
            globalVars.Mtempvar3 = "\(value3)"
            globalVars.Mtempvar4 = "\(value4)"
        })
        
    }
    
    

    //<--------------------------Helathkit Authorization-------------------------->//
    func requestAuthorization()
    {
        let sleepCount = HKObjectType.categoryType(forIdentifier: HKCategoryTypeIdentifier.sleepAnalysis)!
        let stepCount = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount)!
        let activeCalorieCount = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.activeEnergyBurned)!
        let heartRate = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!
        
        if !HKHealthStore.isHealthDataAvailable()
        {
            print("Error")
            return
        }
        
        healthKitStore.requestAuthorization(toShare: [], read: [sleepCount, stepCount, activeCalorieCount, heartRate]) { (success, error) -> Void in print("Auth Success")}
    }

//<--------------------------Reading Health Data from App-------------------------->//
func readHealthData()
{
    //<-------------Sleep------------->//
    if let sleepType = HKObjectType.categoryType(forIdentifier: HKCategoryTypeIdentifier.sleepAnalysis)
    {
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        
        let sleepQuery = HKSampleQuery(sampleType: sleepType, predicate: nil, limit: globalVars.queryLimit, sortDescriptors: [sortDescriptor]){(query, tempResult, error) -> Void in
            if error != nil
            {
                return
            }
            if let result = tempResult
            {
                for item in result
                {
                    if let sample = item as? HKCategorySample{
                        let amount = sample.endDate.timeIntervalSince(sample.startDate)
                        syncPosting(nameInput: "Sleep (seconds)", valueInput: amount, timeInput: (sample.startDate))
                    }}}}
        healthStore.execute(sleepQuery)
    }
    
    
    //<-------------Steps------------->//
    let stepsCount = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount)!
    let stepAssort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)

    let stepQuery = HKSampleQuery(sampleType: stepsCount, predicate: nil, limit: globalVars.queryLimit, sortDescriptors : [stepAssort])
        {query, results, error in
            if let result = results as? [HKQuantitySample] {
                for item in result
                {
                    let steps = Double(item.quantity.doubleValue(for: HKUnit.count()))
                    let stepDate = item.startDate
                    syncPosting(nameInput: "Steps", valueInput: steps, timeInput: stepDate)
                }}}
    healthStore.execute(stepQuery)
    
    

    //<-------------Active Calories------------->//
    let ACaloriesCount = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.activeEnergyBurned)!
    let ACaloriesAssort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)

    let ACalQuery = HKSampleQuery(sampleType: ACaloriesCount, predicate: nil, limit: globalVars.queryLimit, sortDescriptors : [ACaloriesAssort])
        {query, results, error in
            if let result = results as? [HKQuantitySample] {
                for item in result
                {
                    let ACalUnit : HKUnit = HKUnit(from: "Cal")
                    let steps = Double(item.quantity.doubleValue(for: ACalUnit))
                    let stepDate = item.startDate
                    syncPosting(nameInput: "Active_Calories (Cal)", valueInput: steps, timeInput: stepDate)
                }}}
    healthStore.execute(ACalQuery)
    
    
    
    //<-------------Hear Rate------------->//
    let heartRateCount = HKQuantityType.quantityType(forIdentifier: HKQuantityTypeIdentifier.heartRate)!
    let heartRateAssort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
    
    let heartRateQuery = HKSampleQuery(sampleType: heartRateCount, predicate: nil, limit: globalVars.queryLimit, sortDescriptors : [heartRateAssort])
        {query, results, error in
            if let result = results as? [HKQuantitySample] {
                for item in result
                {
                    let heartRateUnit : HKUnit = HKUnit(from: "count/min")
                    let steps = Double(item.quantity.doubleValue(for: heartRateUnit))
                    let stepDate = item.startDate
                    syncPosting(nameInput: "Heart_Rate_(bpm)", valueInput: steps, timeInput: stepDate)
                }}}
    healthStore.execute(heartRateQuery)
    
    
    
//<--------------------------Syncing Health App to Database-------------------------->//
    func syncPosting(nameInput : String?, valueInput : Double?, timeInput : Date?)
    {
        let recordDate = timeInput
        let dateFormat = DateFormatter()
        
        dateFormat.timeStyle = .medium
        dateFormat.dateStyle = .medium
        dateFormat.locale = Locale(identifier: "ja_JP")
        
        let stringDate = dateFormat.string(from: recordDate ?? Date())
        
        
        let post : [String : Any] = ["TimeStamp" : stringDate ,
                                     nameInput ?? "null" : valueInput ?? 0,]
        
        let databaseRef = Database.database().reference()
        
        databaseRef.child("Client_Data").child(nameInput ?? "Dump").childByAutoId().setValue(post)
        
        }
    }
}

