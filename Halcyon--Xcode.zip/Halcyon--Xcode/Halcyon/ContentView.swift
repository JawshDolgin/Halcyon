//
//  ContentView.swift
//  HTN
//
//  Created by Taewoo Ko on 2021-01-16.
//

import SwiftUI
import Foundation

var ratings: [Int] = []

struct SplashView: View {
    
    @State var isActive:Bool = false
    
    var body: some View {
        VStack{
            if self.isActive{
                UserInput()
            }
            else {
                ZStack {
                    
                    Rectangle()
                        .foregroundColor(Color("bg"))
                        .ignoresSafeArea(.all)
                    VStack(alignment: .leading) {
                        Text("Halcyon")
                            .font(.title)
                            .fontWeight(.bold)
                            .foregroundColor(Color(red: 206/255, green: 153/255, blue: 241/255, opacity: 1.0))
                            .multilineTextAlignment(.center)
                        Text("Built for Hack the North")
                            .font(.subheadline)
                    }
                }

                }
            }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.5){
                withAnimation{
                    self.isActive = true
                }
            }
        }
    }
}


struct UserInput: View {
    
    @State private var Button1 = false
    @State private var Button2 = false
    @State private var Button3 = false
    @State private var Button4 = false
    @State private var Button5 = false
    @State private var transitionProd = false
    @State private var index = 0
    @State private var op = 1.0
    @State private var op_temp = 0.0
    @State private var op_button = 1.0
    @State private var survayState = true
    
    var body: some View {
        
        if survayState{
        
        
            ZStack{
                Rectangle()
                    .foregroundColor(Color("bg"))
                    .ignoresSafeArea(.all)
                
                VStack(){
                    switch index {
                    case 0:
                        Text("Happiness")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .offset(y: -100)
                            .animation(.easeInOut(duration:0.5))
                            .opacity(op)
                    case 1:
                        Text("Productivity")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .offset(y: -100)
                            .animation(.easeInOut(duration:0.5))
                            .opacity(op_temp) //1
                    case 2:
                        Text("Creativity")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .offset(y: -100)
                            .animation(.easeInOut(duration:0.5))
                            .opacity(op) //0
                    case 3:
                        Text("Energy")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .offset(y: -100)
                            .animation(.easeInOut(duration:0.5))
                            .opacity(op_temp)
                    default:
                        Text("")
                            .onAppear{
                                withAnimation(.easeOut(duration:1.0)){
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0){
                                        op_button = 0.0
                                    }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5){
                                    
                                        survayState = false
                                        globalVars.happiness = ratings[0]
                                        globalVars.motivation = ratings[1]
                                        globalVars.creativity = ratings[2]
                                        globalVars.energy = ratings[3]

                                        BackendProcesses().mainPosting()
                                        BackendProcesses().getPositions()
                                }
                            }
                        }
                    }
                    HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: 25){
                        Button(action: {
                            self.Button1.toggle()
                            ratings.insert(1, at : index)
                            withAnimation(.easeOut(duration: 0.7))
                            {
                                if index%2 == 0{
                                    self.op = 0
                                }
                                else
                                {
                                    self.op_temp = 0
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7)
                                {
                                    Button1 = false
                                    index+=1
                                    
                                    

                                    //ADD DATA
                                    withAnimation(.easeIn(duration:0.7)){
                                        if (index-1)%2 == 0{
                                            self.op_temp = 1
                                        }
                                        else
                                        {
                                            self.op = 1
                                        }
                                    }
                                }
                            }
                        }){
                            if Button1{
                                Circle()
                                    .frame(width: 45, height: 45)
                                    .foregroundColor(.green)
                            }
                            else
                            {
                                Circle()
                                    .frame(width:45, height: 45)
                                    .opacity(op_button)
                                    .animation(.easeInOut(duration:0.5))
                            }
                        }
                        
                        
                        
                        Button(action: {
                            self.Button2.toggle()
                            ratings.insert(2, at : index)
                            withAnimation(.easeOut(duration: 0.7))
                            {
                                if index%2 == 0{
                                    self.op = 0
                                }
                                else
                                {
                                    self.op_temp = 0
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7)
                                {
                                    Button2 = false
                                    index+=1

                                    //ADD DATA
                                    withAnimation(.easeIn(duration:0.7)){
                                        if (index-1)%2 == 0{
                                            self.op_temp = 1
                                        }
                                        else
                                        {
                                            self.op = 1
                                        }
                                    }
                                }
                            }
                        }){
                            if Button2{
                                Circle()
                                    .frame(width: 45, height: 45)
                                    .foregroundColor(.green)
                            }
                            else
                            {
                                Circle()
                                    .frame(width:45, height: 45)
                                    .opacity(op_button)
                                    .animation(.easeInOut(duration:0.5))
                            }
                        }
                        
                        
                        
                        Button(action: {
                            self.Button3.toggle()
                            ratings.insert(3, at : index)
                            withAnimation(.easeOut(duration: 0.7))
                            {
                                if index%2 == 0{
                                    self.op = 0
                                }
                                else
                                {
                                    self.op_temp = 0
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7)
                                {
                                    Button3 = false
                                    index+=1

                                    //ADD DATA
                                    withAnimation(.easeIn(duration:0.7)){
                                        if (index-1)%2 == 0{
                                            self.op_temp = 1
                                        }
                                        else
                                        {
                                            self.op = 1
                                        }
                                    }
                                }
                            }
                        }){
                            if Button3{
                                Circle()
                                    .frame(width: 45, height: 45)
                                    .foregroundColor(.green)
                            }
                            else
                            {
                                Circle()
                                    .frame(width:45, height: 45)
                                    .opacity(op_button)
                                    .animation(.easeInOut(duration:0.5))
                            }
                        }
                        
                        
                        
                        Button(action: {
                            self.Button4.toggle()
                            ratings.insert(4, at : index)
                            withAnimation(.easeOut(duration: 0.7))
                            {
                                if index%2 == 0{
                                    self.op = 0
                                }
                                else
                                {
                                    self.op_temp = 0
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7)
                                {
                                    Button4 = false
                                    index+=1

                                    //ADD DATA
                                    withAnimation(.easeIn(duration:0.7)){
                                        if (index-1)%2 == 0{
                                            self.op_temp = 1
                                        }
                                        else
                                        {
                                            self.op = 1
                                        }
                                    }
                                }
                            }
                        }){
                            if Button4{
                                Circle()
                                    .frame(width: 45, height: 45)
                                    .foregroundColor(.green)
                            }
                            else
                            {
                                Circle()
                                    .frame(width:45, height: 45)
                                    .opacity(op_button)
                                    .animation(.easeInOut(duration:0.5))
                            }
                        }
                        
                        
                        
                        Button(action: {
                            self.Button5.toggle()
                            ratings.insert(5, at : index)
                            withAnimation(.easeOut(duration: 0.7))
                            {
                                if index%2 == 0{
                                    self.op = 0
                                }
                                else
                                {
                                    self.op_temp = 0
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.7)
                                {
                                    Button5 = false
                                    index+=1

                                    //ADD DATA
                                    withAnimation(.easeIn(duration:0.7)){
                                        if (index-1)%2 == 0{
                                            self.op_temp = 1
                                        }
                                        else
                                        {
                                            self.op = 1
                                        }
                                    }
                                }
                            }
                        }){
                            if Button5{
                                Circle()
                                    .frame(width: 45, height: 45)
                                    .foregroundColor(.green)
                            }
                            else
                            {
                                Circle()
                                    .frame(width:45, height: 45)
                                    .opacity(op_button)
                                    .animation(.easeInOut(duration:0.5))
                            }
                        }
                    }
                }
            }
        }
        else{
            Report()
            
        }
    }
}

struct Report: View {
    
    @State var op = 0.0
    @State var count = 0
    
    var body: some View {
        ZStack{
            Rectangle()
                .foregroundColor(Color("bg"))
                .ignoresSafeArea(.all)
                .animation(.easeInOut(duration:0.5))
                .opacity(op)
                .onAppear{
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                        op = 1.0
                    }
                    
                }
            VStack(alignment: .leading){
                //TEXT FOR OUTPUT
                switch count {
                case 0:
                    Text("Happiness")
                        .font(.title)
                        .fontWeight(.medium)
                        .multilineTextAlignment(.center)
                        .offset(y:-10)
                        .animation(.easeInOut(duration:0.5))
                    HStack(spacing: 50) {
                        Text(globalVars.Htte1)
                        Text(globalVars.Htempvar1)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Htte2)
                        Text(globalVars.Htempvar2)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Htte3)
                        Text(globalVars.Htempvar3)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Htte4)
                        Text(globalVars.Htempvar4)
                    }
                case 1:
                    Text("Productivity")
                        .font(.title)
                        .fontWeight(.medium)
                        .multilineTextAlignment(.center)
                        .offset(y: -10)
                        .animation(.easeInOut(duration:0.5))
                    HStack(spacing: 50) {
                        Text(globalVars.Mtte1)
                        Text(globalVars.Mtempvar1)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Mtte2)
                        Text(globalVars.Mtempvar2)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Mtte3)
                        Text(globalVars.Mtempvar3)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Mtte4)
                        Text(globalVars.Mtempvar4)
                    }
                case 2:
                    Text("Creativity")
                        .font(.title)
                        .fontWeight(.medium)
                        .multilineTextAlignment(.center)
                        .offset(y: -10)
                        .animation(.easeInOut(duration:0.5))
                    HStack(spacing: 50) {
                        Text(globalVars.Ctte1)
                        Text(globalVars.Ctempvar1)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Ctte2)
                        Text(globalVars.Ctempvar2)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Ctte3)
                        Text(globalVars.Ctempvar3)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Ctte4)
                        Text(globalVars.Ctempvar4)
                    }
                case 3:
                    Text("Energy")
                        .font(.title)
                        .fontWeight(.medium)
                        .multilineTextAlignment(.center)
                        .offset(y: -10)
                        .animation(.easeInOut(duration:0.5))
                    HStack(spacing: 50) {
                        Text(globalVars.Ette1)
                        Text(globalVars.Etempvar1)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Ette2)
                        Text(globalVars.Etempvar2)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Ette3)
                        Text(globalVars.Etempvar3)
                    }
                    HStack(spacing: 50) {
                        Text(globalVars.Ette4)
                        Text(globalVars.Etempvar4)
                    }
                default:
                    Text("")
                }

            }
            VStack{
                if count < 4{
                    Button(action: {count += 1})
                    {
                        Text("Next")
                            .multilineTextAlignment(.center)
                            .padding()
                    }
                    .offset(y: 100)
                }

            }
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            UserInput()
            Report()
        }
    }
}
